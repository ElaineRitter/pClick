import java.sql.*;

public class DBConnect {
 private Connection con; 
 private Statement st; 
 private ResultSet rs; 
 
 
 public DBConnect(){ 
	 try{ 
		 Class.forName("com.mysql.jdbc.Driver");
	     con = DriverManager.getConnection("jdbc:mysql://localhost:3306/clicker", "root", "");
	     st = con.createStatement();
		 
	 }catch(Exception ex){
		 System.out.println("Error: " + ex); 
		 
	 }
 } 
 
 
 public void getcoursename(){ 
	 try{ 
		 String query = "SELECT course_name FROM course"; 
		 rs = st.executeQuery(query); 
		 System.out.println("Records from database");
		 while(rs.next()){ 
			// String id = rs.getString("id");
			 String coursename = rs.getString("course_name"); 
			 System.out.println("The courses are: " + coursename);
			 
		 }
		 
	 }catch(Exception ex){ 
		 System.out.println(ex);
	 }
 }
 
 public void getanswer(){ 
	 try{ 
		 String query = "SELECT answer FROM question"; 
		 rs = st.executeQuery(query); 
		 System.out.println("Records from database");
		 while(rs.next()){ 
			// String id = rs.getString("id");
			 String answer = rs.getString("answer"); 
			 System.out.println("The answer is: " + answer);
			 
		 }
		 
	 }catch(Exception ex){ 
		 System.out.println(ex);
	 }
 }
	 
	 
	 public void getclickerid(){ 
		 try{ 
			 String query = "SELECT clickerID FROM votes"; 
			 rs = st.executeQuery(query); 
			 System.out.println("Records from database");
			 while(rs.next()){ 
				// String id = rs.getString("id");
				 String clickerid = rs.getString("clickerID"); 
				 System.out.println("The clicker ID is: " + clickerid);
				 
			 }
			 
		 }catch(Exception ex){ 
			 System.out.println(ex);
		 }
	 
	 
	 
	 
 }
 
 
 
	
	
	
}
